package com.example.myai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF09070F)
private val Panel = Color(0xFF171321)
private val Purple = Color(0xFF9B6DFF)
private val TextMain = Color(0xFFF5F0FF)
private val Muted = Color(0xFFAAA1B9)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyAIApp() }
    }
}

@Composable
fun MyAIApp() {
    var input by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hello! I'm MyAI. My offline AI engine will be connected in the next development step.", false)
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Background,
        surface = Panel,
        primary = Purple,
        onBackground = TextMain,
        onSurface = TextMain
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Background)
                .statusBarsPadding().navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(42.dp).background(Purple, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("M", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MyAI", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("PERSONAL • ON-DEVICE AI", color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
                }
                Box(Modifier.background(Color(0xFF251B37), CircleShape).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("LOCAL", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(color = Color(0xFF292333))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("YOUR PRIVATE AI SPACE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                items(messages) { message ->
                    MessageBubble(message)
                }
            }

            Column(Modifier.fillMaxWidth().background(Panel).padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFF241D30), RoundedCornerShape(24.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        textStyle = TextStyle(color = TextMain, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(Purple),
                        decorationBox = { inner ->
                            Box {
                                if (input.isEmpty()) Text("Message MyAI...", color = Muted, fontSize = 15.sp)
                                inner()
                            }
                        }
                    )
                    Spacer(Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val prompt = input.trim()
                            if (prompt.isNotEmpty()) {
                                messages.add(ChatMessage(prompt, true))
                                messages.add(ChatMessage(
                                    "The chat interface is ready. The local language model is not connected yet, so I can't answer this prompt until the AI engine is added.",
                                    false
                                ))
                                input = ""
                            }
                        },
                        enabled = input.isNotBlank(),
                        shape = CircleShape,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("Send", color = Color.White) }
                }
                Spacer(Modifier.height(8.dp))
                Text("Starter preview • AI model integration comes next", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier.widthIn(max = 300.dp)
                .background(
                    if (message.fromUser) Color(0xFF493078) else Panel,
                    RoundedCornerShape(18.dp)
                )
                .padding(14.dp)
        ) {
            Text(
                if (message.fromUser) "YOU" else "MYAI",
                color = if (message.fromUser) Color(0xFFE2D3FF) else Purple,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(5.dp))
            Text(message.text, color = TextMain, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}
