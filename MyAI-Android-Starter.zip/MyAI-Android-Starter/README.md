# MyAI — Android starter

A dark black + purple Android chat UI starter for a personal offline AI.

## Important status

This is **starter source code**, not a finished AI assistant. The chat screen is implemented, but no language model is bundled or connected yet. The current reply explicitly tells you that the local model is not connected.

## Build without owning a computer

1. Create a GitHub account and a new repository named `MyAI`.
2. Upload the contents of this folder to the repository (keep the folder structure).
3. Open the repository's **Actions** tab.
4. Select **Build MyAI APK** and tap **Run workflow** (or push to `main`).
5. When the workflow finishes, open the run and download the `MyAI-debug-apk` artifact.
6. Extract the downloaded ZIP on your Android phone and install `app-debug.apk`.

GitHub builds the starter app in the cloud. You need internet for uploading source and downloading the APK. The eventual AI model will be downloaded separately once, then used offline.

## Requirements and next development steps

- Android 8.0 or newer (minSdk 26).
- Android Studio/Gradle build uses Java 17, Gradle 8.9 and Android Gradle Plugin 8.7.3.
- Next: integrate a small, quantized GGUF model through a compatible Android native inference runtime; store the model locally; add model loading, streaming generation, cancellation and local chat persistence.
- A 4 GB RAM phone is constrained. Start with a very small quantized model and benchmark memory use before attempting larger models.

## App identity

- Display name: MyAI
- Theme: dark black + purple
- Application ID placeholder: `com.example.myai`

Before public distribution, change the application ID to a unique ID you control and create a release signing key. Never share the signing key or passwords.
